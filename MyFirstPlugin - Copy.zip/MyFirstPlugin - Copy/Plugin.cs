﻿using BepInEx;
using BepInEx.Logging;
using BepInEx.Unity.IL2CPP;
using UnityEngine;

namespace MyFirstPlugin;

[BepInPlugin("com.luckyecho.plugins.exampleplugin", "example plugin", "1.0.0.0")]
public class Plugin : BasePlugin
{
    internal static new ManualLogSource Log;

    public override void Load()
    {
        // Plugin startup logic
        Log = base.Log;
        Log.LogInfo($"Plugin {MyPluginInfo.PLUGIN_GUID} is loaded! ");
        var componentInstance = IL2CPPChainloader.AddUnityComponent(typeof(MyGuiBehaviour)); // Creates a gameobject and also adds to the interal bepinex manager.
    }
}

public class MyGuiBehaviour : MonoBehaviour
{
    void OnGUI()
    {
        if (GUI.Button(new Rect(10, 10, 150, 30), "Click Me!"))
        {
            Plugin.Log.LogInfo("Button clicked!");
        }

        GUI.Label(new Rect(10, 50, 250, 30), "Hello from BepInEx IL2CPP plugin!");
    }
}